import keyMirror from 'keymirror'

export default keyMirror({
  SET_PROVIDER: null,
  ROUND_RESULTS: null,
  STATS: null
})
