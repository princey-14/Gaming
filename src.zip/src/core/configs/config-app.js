export const appConfig = {
  name: 'Ether\'s List'
}
